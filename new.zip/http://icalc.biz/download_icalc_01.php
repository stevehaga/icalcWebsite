<html>

<head>

<title>iCalc - Download Page</title>

<style type="text/css">
h4 {
	font: normal small Arial, Helvetica, sans-serif;
	margin: 10px 40px;
}
h3 {
	font: bold 28px Arial, Helvetica, sans-serif;
	color: #000079;
	margin-top: 20px;
}
</style>

</head>



<body bgcolor="#FFFFFF">
<div align="center">
  <table width="800" border="0" cellspacing="0" cellpadding="0">
    
    <tr>
      
      <td> 
        
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          
          <tr>
            
            <td>
              
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                
                <tr bgcolor="#000000"> 
                  
                  <td>
                    
                    <table width="100%" border="0" cellspacing="3" cellpadding="0">
                      
                      <tr>
                        
                        <td>
                          
                          <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            
                            <tr> 
                              
                              <td width="24%" bgcolor="#FFFFFF"> 
                                <div align="center"><img src="img/logo_icalc.gif" width="147" height="70"></div>                            </td>
  
                            <td width="76%"> 
                              
                              <table border="0" cellspacing="0" cellpadding="6" width="600">
                                
                                <tr bgcolor="#000079"> 
                                  <td> 
                                    <div align="center"><img src="img/masthead.gif" width="400" height="60">
                                      <map name="Map2"><area shape="rect" coords="-12,-1,52,79" href="http://www.yahoo.com/r/a1"><area shape="rect" coords="65,0,129,80" href="http://www.yahoo.com/r/p1"><area shape="rect" coords="133,0,197,72" href="http://www.yahoo.com/r/m1"><area shape="rect" coords="203,0,271,84" href="http://www.yahoo.com/r/wn"><area shape="rect" coords="277,2,337,76" href="http://www.yahoo.com/r/i1"><area shape="rect" coords="349,0,409,72" href="http://www.yahoo.com/r/hw"></map></div>                                  </td>
                                </tr>
                                </table>                            </td>
                          </tr>
                          </table>                      </td>
                    </tr>
                    </table>                </td>
              </tr>
              </table>          </td>
        </tr>
        </table>
  
      <table width="100%" border="0" cellspacing="0" cellpadding="3">
        
        <tr bgcolor="#000079"> 
          
          <td> 
            
            <table border="0" cellspacing="1" cellpadding="4" width="100%">
              <tr bgcolor="#FFFFFF"> 
                <td><div align="center"><u><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><a href="download_icalc_01.php"><font color="#000000">Free 
                  Calculators</font></a></font></b></u></div></td>
                <td> 
                    <div align="center"><u><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><a href="products.html"><font color="#000000">Future 
                      Products</font></a></font></b></u></div>                  </td>
                  <td> 
                    <div align="center"><u><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><a href="templates.html"><font color="#000000">Excel 
                      Templates</font></a></font></b></u></div>                  </td>
                  <td> 
                    <div align="center"><u><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><a href="membership.html"><font color="#000000">Free 
                      Updates</font></a></font></b></u></div>                  </td>
                  <td> 
                    <div align="center"><u><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><a href="mailto:hubbell@comcast.net"><font color="#000000">Contact</font></a></font></b></u></div>                  </td>
                </tr>
              </table>          </td>
        </tr>
        </table>
  
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        
        <tr bgcolor="#000079"> 
          
          <td> 
            
            <table width="800" border="0" cellspacing="3" cellpadding="0" bgcolor="#000079">
              
              <tr> 
                
                <td width="155">
                  <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" color="#FFFFFF" size="2"><b>Calculators</b></font></div>                  </td>
  
                <td bgcolor="#000079"> 
                  
                  <div align="right"> </div>                </td>
              </tr>
              
              <tr> 
                
                <td width="155" valign="top"> 
                  
                  <table width="100%" border="0" cellspacing="0" cellpadding="1">
                    <tr> 
                      <td><table width="100%" border="0" cellspacing="2" cellpadding="6">
                        <tr bgcolor="#FFFFE1">
                          <td><div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><u><a href="personal.html"><font color="#000000">Personal</font></a> </u></font></div></td>
                        </tr>
                        <tr bgcolor="#FFFFE1">
                          <td><div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><u><a href="loan.html"><font color="#000000">Loan</font></a> </u></font></div></td>
                        </tr>
                        <tr bgcolor="#FFFFE1">
                          <td><div align="center"><u><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><a href="loanplus.html"><font color="#000000">Loan 
                            Plus</font></a></font></u></div></td>
                        </tr>
                        <tr bgcolor="#FFFFE1">
                          <td><div align="center"><u><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><a href="loanballoon.html"><font color="#000000">Loan 
                            Balloon</font></a></font></u></div></td>
                        </tr>
                        <tr bgcolor="#FFFFE1">
                          <td><div align="center"><u><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><a href="lease.html"><font color="#000000">Lease</font></a></font></u></div></td>
                        </tr>
                        <tr bgcolor="#FFFFE1">
                          <td><div align="center"><u><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><a href="leaseplus.html"><font color="#000000">Lease 
                            Plus</font></a></font></u></div></td>
                        </tr>
                        <tr bgcolor="#FFFFE1">
                          <td><div align="center"><u><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><a href="investment.html"><font color="#000000">Investment</font></a></font></u></div></td>
                        </tr>
                        <tr bgcolor="#FFFFE1">
                          <td><div align="center"><u><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><a href="mortgage.html"><font color="#000000">Mortgage</font></a></font></u></div></td>
                        </tr>
                        <tr bgcolor="#FFFFE1">
                          <td><div align="center"><u><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><a href="mortgagepiti.html"><font color="#000000">Mortgage 
                            PITI</font></a></font></u></div></td>
                        </tr>
                        <tr bgcolor="#FFFFE1">
                          <td><div align="center"><u><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><a href="mortgageprequal.html"><font color="#000000">Mortgage 
                            PreQual</font></a></font></u></div></td>
                        </tr>
                        <tr bgcolor="#FFFFE1">
                          <td><div align="center"><u><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><a href="savings.html"><font color="#000000">Savings</font></a></font></u></div></td>
                        </tr>
                        <tr bgcolor="#FFFFE1">
                          <td><div align="center"><u><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><a href="addition.html"><font color="#000000">Addition</font></a></font></u></div></td>
                        </tr>
                      </table>
                      <p align="center">&nbsp;</p>
                        </td>
                    </tr>
                    </table>                </td>
  
                <td bgcolor="#FFFFFF" valign="top"> 
  

                    <p align="center"><img src="img/icalc_logo.jpg" width="270" height="106" border="0"></p>

                    <p align="center"><img src="img/omg.jpg" border="0"></p>
					
					<form name="form1" method="post" action="send_contact.php">
					
                    <table width="300" align=CENTER border=0>
                      <tr> 
                        <td> 
                          <p><font face=ARIAL size=3>Name:</font> 
                        </td>
                        <td align=RIGHT> 
                          <input name="name" type="text" id="name" size=25>
                        </td>
                      </tr>
                      <tr> 
                        <td> 
                          <p><font face=ARIAL size=3>Email:</font> 
                        </td>
                        <td align=RIGHT> 
                          <input name="email" type="text" id="email" size=25>
                        </td>
                      </tr>
                    </table>
                    <font face="Verdana, Arial, Helvetica, sans-serif" size="2"><br>
                    </font><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    </font>

                    <table align=CENTER width="400" border="0">
                      <tr>
					  <td><font face=ARIAL size=3>Comments:</font></td>
					  </tr>
                        <td width=100%> 
						  <textarea name="comments" cols="50" rows="4" id="comments"></textarea>
                        </td>
                      </tr>
                    </table>
                    </br>	
					<!--<table align=CENTER border="0">
                      <tr> 
                        <td> 
                          <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="4">
                            Send a friend an iCalc financial calculator.</font> 
                          </div>
                        </td>
                      </tr>
                    </table>-->
                    <!--<table align=CENTER width="300" border="0">
                      <tr> 
                        <td> 
                          <p><font face=ARIAL size=3>Friend Email 1:</font> 
                        </td>
                        <td align=RIGHT> 
                          <input type=TEXT name="email1" size=25>
                        </td>
                      </tr>
                      <tr> 
                        <td> 
                          <p><font face=ARIAL size=3>Friend Email 2:</font> 
                        </td>
                        <td align=RIGHT> 
                          <input type=TEXT name="email2" size=25>
                        </td>
                      </tr>
                      <tr> 
                        <td> 
                          <p><font face=ARIAL size=3>Friend Email 3:</font> 
                        </td>
                        <td align=RIGHT> 
                          <input type=TEXT name="email3" size=25>
                        </td>
                      </tr>
                      <tr> 
                        <td> 
                          <p><font face=ARIAL size=3>Friend Email 4:</font> 
                        </td>
                        <td align=RIGHT> 
                          <input type=TEXT name="email4" size=25>
                        </td>
                      </tr>
                      <tr> 
                        <td> 
                          <p><font face=ARIAL size=3>Friend Email 5:</font> 
                        </td>
                        <td align=RIGHT> 
                          <input type=TEXT name="email5" size=25>
                        </td>
                      </tr>
                      <tr> 
                        <td> 
                          <p><font face=ARIAL size=3>Friend Email 6:</font> 
                        </td>
                        <td align=RIGHT> 
                          <input type=TEXT name="email6" size=25>
                        </td>
                      </tr>
                      <tr> 
                        <td> 
                          <p><font face=ARIAL size=3>Friend Email 7:</font> 
                        </td>
                        <td align=RIGHT> 
                          <input type=TEXT name="email7" size=25>
                        </td>
                      </tr>
                      <tr> 
                        <td> 
                          <p><font face=ARIAL size=3>Friend Email 8:</font> 
                        </td>
                        <td align=RIGHT> 
                          <input type=TEXT name="email8" size=25>
                        </td>
                      </tr>
                    </table>-->
					<table align=CENTER width="400" border="0">
                      <tr> 
                        <!--<td width=60%> <font face=ARIAL size=3>For proper installation 
                          choose "run" after downloading</font> </td>-->
                        <td width=40%> 
							<div align="center">
							  <input type=image src="img/submit_button.jpg" name="submit">
						    </div></td>
					  </tr>
                    </table>
                    <p>&nbsp;</p>
                  </form>
              </table>          </td>
        </tr>
        </table>
  
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        
        <tr bgcolor="#000079"> 
          
          <td>
            
            <table width="100%" border="0" cellspacing="1" cellpadding="3" bgcolor="#000079">
              <tr bgcolor="#FFFFFF"> 
                <td> 
                  <div align="center"><u><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="index.html"><font color="#000000">Home</font></a></font></u></div>                  </td>
                  <td> 
                    <div align="center"><u><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="download_icalc_01.php"><font color="#000000">Calculators</font></a></font></u></div>                  </td>
                  <td> 
                    <div align="center"><u><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="products.html"><font color="#000000">Future 
                      Products</font></a></font></u></div>                  </td>
                  <td> 
                    <div align="center"><u><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="templates.html"><font color="#000000">Templates</font></a></font></u></div>                  </td>
                  <td> 
                    <div align="center"><u><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="membership.html"><font color="#000000">Free 
                      Updates</font></a></font></u></div>                  </td>
                  <td> 
                    <div align="center"><u><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="mailto:hubbell@comcast.net"><font color="#000000">Contact 
                      Us</font></a></font></u></div>                  </td>
                </tr>
              </table>          </td>
        </tr>
        </table>    </td>
  </tr>
  </table>
</div>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-8430655-1");
pageTracker._trackPageview();
} catch(err) {}
</script>
</body>

</html>

